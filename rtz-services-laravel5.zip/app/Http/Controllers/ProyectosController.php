<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProyectosController extends Controller{
    public function proyecto(){
        $results = DB::select( DB::raw('select * FROM proyectos;') );   
        return response()->json([
            200 => 'OK',
            'result' => $results,
        ], 200);
    }
}
